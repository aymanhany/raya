import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xff1466AF);
const Color kBorderColor = Color.fromARGB(150, 112, 112, 112);
