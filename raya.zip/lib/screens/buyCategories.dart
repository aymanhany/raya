// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:raya/colors.dart';

class BuyCategories extends StatefulWidget {
  const BuyCategories({Key? key}) : super(key: key);

  @override
  State<BuyCategories> createState() => _BuyCategoriesState();
}

class _BuyCategoriesState extends State<BuyCategories> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(100),
        child: AppBar(
          toolbarHeight: 100,
          elevation: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: Icon(Icons.notifications),
            color: kPrimaryColor,
            onPressed: () {},
          ),
          title: Center(
              child: Image.asset(
            'images/Raya-Logo.png',
            width: MediaQuery.of(context).size.width * 0.2,
          )),
          actions: [
            IconButton(
              icon: Image.asset('images/Share-Icon.png'),
              onPressed: () {},
            ),
            SizedBox(width: 10),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            image: DecorationImage(
              image: AssetImage('images/BG.png'),
              fit: BoxFit.cover,
            ),
          ),
          child: Column(
            children: <Widget>[
              Text(
                'Choose your vehicle',
                style: TextStyle(fontSize: 41, color: kPrimaryColor),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.05),
              GestureDetector(
                onTap: () {
                  Navigator.pushNamed(context, '/buy_inner_categories');
                },
                child: Container(
                  child: Stack(
                    alignment: Alignment.bottomRight,
                    children: <Widget>[
                      Container(
                        height: MediaQuery.of(context).size.height * .15,
                        margin:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(16, 0, 0, 0),
                                blurRadius: 10,
                                spreadRadius: 5,
                                offset: Offset(0, 6),
                              ),
                            ]),
                      ),
                      Container(
                        // height: MediaQuery.of(context).size.height * .15,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.only(top: 30.0),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      'images/Cart.png',
                                      width: 20,
                                    ),
                                    Text(
                                      'Car',
                                      style: TextStyle(
                                        fontSize: 18,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(right: 30.0),
                              child: Image.asset(
                                'images/Cart.png',
                                width: MediaQuery.of(context).size.width * .5,
                                alignment: Alignment.center,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.05),
              Container(
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: <Widget>[
                    Container(
                      height: MediaQuery.of(context).size.height * .15,
                      margin:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(16, 0, 0, 0),
                              blurRadius: 15,
                              spreadRadius: 8,
                              offset: Offset(0, 0),
                            ),
                          ]),
                    ),
                    Container(
                      // height: MediaQuery.of(context).size.height * .15,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 30.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Image.asset(
                                    'images/Cart.png',
                                    width: 20,
                                  ),
                                  Text(
                                    'Car',
                                    style: TextStyle(
                                      fontSize: 18,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 30.0),
                            child: Image.asset(
                              'images/Cart.png',
                              width: MediaQuery.of(context).size.width * .5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.05),
              Container(
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: <Widget>[
                    Container(
                      height: MediaQuery.of(context).size.height * .15,
                      margin:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(16, 0, 0, 0),
                              blurRadius: 15,
                              spreadRadius: 8,
                              offset: Offset(0, 0),
                            ),
                          ]),
                    ),
                    Container(
                      // height: MediaQuery.of(context).size.height * .15,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.only(top: 30.0),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Image.asset(
                                    'images/Cart.png',
                                    width: 20,
                                  ),
                                  Text(
                                    'Car',
                                    style: TextStyle(
                                      fontSize: 18,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 30.0),
                            child: Image.asset(
                              'images/Cart.png',
                              width: MediaQuery.of(context).size.width * .5,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
